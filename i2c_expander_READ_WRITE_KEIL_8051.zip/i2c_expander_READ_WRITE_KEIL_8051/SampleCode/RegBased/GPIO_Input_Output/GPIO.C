#include "MUG51.h"

#define print_function 

#define I2C_CLOCK                 13
#define I2C_Expander_SLAVE_ADDRESS	0x40
#define I2C_WR                    0
#define I2C_RD                    1

#define I2C_SENSOR_ADDRESS	0X76

UINT8 TEMP_MSB = 0x00;
UINT8 TEMP_LSB = 0x00;
UINT8 TEMP_XLSB = 0x00;

#define TEMP_REG_MSB 0XFA
#define TEMP_REG_LSB 0XFB
#define TEMP_REG_XLSB 0XFC

UINT8 ret_data[3];
UINT8 send_data[3];
UINT8 rd_data = 0x00;
UINT8 wr_data = 0xAA;

UINT8 check = 0xAA;


void I2C0_Master_Init(void)
{
    MFP_P25_I2C0_SCL;
    P25_OPENDRAIN_MODE;         
    MFP_P24_I2C0_SDA;
    P24_OPENDRAIN_MODE;          

    SFRS = 0;
   
    I2C0CLK = I2C_CLOCK; 

    set_I2C0CON_I2CEN;                                   
}

void I2C_Error(void)
{
    while(1);
}

void my_delay(unsigned int time)
{
		volatile unsigned int i;
		volatile unsigned int j;
		i=time;
		for(i;i>0;i--)
		{
			j=0;
			for(j;j<900;j++);
		}
}

void I2C0_Master_Start_Bit(void)
{
		set_I2C0CON_STA;
    clr_I2C0CON_SI;          
    while (!(I2C0CON&SET_BIT3));                                
    if (I2C0STAT != 0x08)                         
        I2C_Error();
}

void I2C0_Master_Send_Slave_Add(UINT8 device_add, UINT8 mood)
{
		UINT8 Add_Ack_Check;
		clr_I2C0CON_STA;                                    
		I2C0DAT = (device_add |mood);
		clr_I2C0CON_SI;
		while (!(I2C0CON&SET_BIT3));
	
		if(mood)
				Add_Ack_Check = 0x40;
		else
			Add_Ack_Check = 0x18;
		
		if (I2C0STAT != Add_Ack_Check)
				I2C_Error();
}

void I2C0_Master_Byte_Write(UINT8 DATA)
{
		I2C0DAT = DATA;
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));
	
		if (I2C0STAT != 0x28)
       I2C_Error();
}

void I2C0_Master_Multi_Byte_Write(UINT8 *rd_data_add, UINT8 data_size)
{
		unsigned char  Count;
		for (Count = 0; Count < data_size; Count++)
		{
			I2C0DAT = (UINT8)(*rd_data_add);
			clr_I2C0CON_SI;
			while (!(I2C0CON&SET_BIT3)); 	
		
			if (I2C0STAT != 0x28)
				I2C_Error();
		
			rd_data_add++;
		}
}

void I2C0_Master_Byte_Read(void)
{
		set_I2C0CON_AA;
    clr_I2C0CON_SI;        
    while (!(I2C0CON&SET_BIT3)); 	
	
    if (I2C0STAT != 0x50)              
        I2C_Error();
				
		rd_data = I2C0DAT;
		clr_I2C0CON_AA;
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));
	
    if (I2C0STAT != 0x58)
        I2C_Error();
}

void I2C0_Master_Multi_Byte_Read(UINT8 *rd_buffer, UINT8 read_size)
{
		unsigned char  Count;
		for (Count = 0; Count <read_size; Count++)
		{
			set_I2C0CON_AA;
			clr_I2C0CON_SI;        
			while (!(I2C0CON&SET_BIT3));                            

			if (I2C0STAT != 0x50)              
				I2C_Error();
				
			*rd_buffer = I2C0DAT;
			rd_buffer++;
			
			clr_I2C0CON_AA;
			clr_I2C0CON_SI;
			while (!(I2C0CON&SET_BIT3));
	
			if (I2C0STAT != 0x58)
					I2C_Error();
		}
}

void I2C0_Master_Stop_bit(void)
{
		set_I2C0CON_STO;
		clr_I2C0CON_SI;
		while(I2C0CON&SET_BIT4);                                
}



void main(void)
{
		I2C0_Master_Init();
	
			
		I2C0_Master_Start_Bit();
		I2C0_Master_Send_Slave_Add(I2C_Expander_SLAVE_ADDRESS, I2C_WR);
		I2C0_Master_Byte_Write(wr_data);
		I2C0_Master_Stop_bit();
		check = rd_data;
		my_delay(1000);	
	
		I2C0_Master_Start_Bit();
		I2C0_Master_Send_Slave_Add(I2C_Expander_SLAVE_ADDRESS, I2C_RD);
		I2C0_Master_Byte_Read();
		I2C0_Master_Stop_bit();
		check = rd_data;
		my_delay(1000);
	
	/*I2C0_Master_Start_Bit();
		I2C0_Master_Send_Slave_Add(I2C_SENSOR_ADDRESS, I2C_WR);
		I2C0_Master_Send_Slave_Add(0xD0, I2C_RD);
		I2C0_Master_Byte_Read();
		I2C0_Master_Stop_bit();
		check = rd_data;
		my_delay(1000);*/
    while (1);

}